import React from "react";
import ReactDOM from "react-dom";
import "./styles.css";

//import App from "./App1";
//import App from "./App2";
//import App from "./App3";
//import App from "./App4";
//import App from "./App5";
import App from "./App6";

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
